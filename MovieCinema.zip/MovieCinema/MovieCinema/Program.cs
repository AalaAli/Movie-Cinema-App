﻿using MovieCinema.Actors;
using MovieCinema.Genres;
using MovieCinema.Movies;
using MovieCinema.Repositories;
using MovieCinema.Seats;
using MovieCinema.ShowTimes;
using MovieCinema.Tickets;
using MovieCinema.Users;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace MovieCinema
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }

}
  



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieCinema.Repositories;
namespace MovieCinema.Halls
{
    public class HallService
    {
 /*      private readonly IRepository<Hall> _hallRepository;
        public HallService(IRepository<Hall> repository)
        {
            _hallRepository = repository;
        }
        public void AddHall(Hall hall)
        {
            _hallRepository.Add(hall);
        }
        public void DeleteHall(int id)
        {
            _hallRepository.Delete(id);
        }
        public void UpdateHall(Hall hall)
        {
            _hallRepository.Update(hall);
        }
        public Hall GetHallById(int id)
        {
            return _hallRepository.GetById(id);
        }
        public List<Hall> GetAllHall()
        {
            return _hallRepository.GetAll();
        }*/

    }
}
